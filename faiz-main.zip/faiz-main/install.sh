termux-setup-storage -y
apt update -y && apt upgrade -y
pkg update -y && pkg upgrade-y
pkg install wget
pkg install python
pkg install python3
pkg install git
pkg install figlet
pip install requests
pip install termcolor
pip install colr
pip install httpx
pip install colorm -y
pip install wget -y
pip install sys
pip install time -y
