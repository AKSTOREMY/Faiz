<img align="center" alt="profile" width="500" src="https://im.ezgif.com/tmp/ezgif-1-555f66128a.gif">
<h1 align="center">Hi 👋, Thanks to order</h1>
<h3 align="center"> You Can Order Now</h3>


- 👯 Order on Whatsapp [Whatsapp](https://wa.me/+6285953890866)

<h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://instagram.com/dellstorecpm" target="blank"><img align="center" src="https://media.tenor.com/aCp70-I4zIkAAAAC/instagram-logo.gif " alt="dellstorecpm" height="30" width="40" /></a>
<a href="https://wa.me/+6281990236975" target="blank"><img align="center" src="https://media.tenor.com/rZPzTbfYtC4AAAAM/whats-app.gif" alt="My Whatsapp" height="30" width="40" /></a>
<a href="https://www.tiktok.com/@dellstorecpm.id/" target="blank"><img align="center" src="https://i.pinimg.com/originals/77/97/19/7797190f0f3efd9d5b0b96963d97ed5a.gif" alt="My tiktok" height="30" width="40" /></a>
<a href="https://facebook.com/adelaparamayoga" target="blank"><img align="center" src="https://static.dezeen.com/uploads/2019/11/facebook-redesign_dezeen-sq.gif" alt="My tiktok" height="80" width="80" /></a>
</p>

<h3 align="left">Languages and Tools:</h3>
<p align="left"> <a href="https://developer.android.com" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/android/android-original-wordmark.svg" alt="android" width="40" height="40"/> </a> <a href="https://www.w3schools.com/cpp/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/cplusplus/cplusplus-original.svg" alt="cplusplus" width="40" height="40"/> </a> <a href="https://firebase.google.com/" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/firebase/firebase-icon.svg" alt="firebase" width="40" height="40"/> </a> <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> </a> <a href="https://nodejs.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original-wordmark.svg" alt="nodejs" width="40" height="40"/> </a> <a href="https://www.php.net" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/php/php-original.svg" alt="php" width="40" height="40"/> </a> <a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> </p>


